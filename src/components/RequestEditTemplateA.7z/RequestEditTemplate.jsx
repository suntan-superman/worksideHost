/* eslint-disable */

import React, { useEffect, useRef, useState, useCallback } from "react";
import { DropDownListComponent } from "@syncfusion/ej2-react-dropdowns";
import {
	DatePickerComponent,
	DateTimePickerComponent,
} from "@syncfusion/ej2-react-calendars";
import { NumericTextBoxComponent } from "@syncfusion/ej2-react-inputs";
import "../styles/material.css";

import {
	GetAllProjects,
	GetAllFirms,
	GetProducts,
	GetAllContacts,
	GetSupplierProductsByProduct,
	getRequestTemplates,
	createRequestTemplate,
} from "../api/worksideAPI";
import { useQuery } from "@tanstack/react-query";

import {
	showErrorDialog,
	showSuccessDialogWithTimer,
} from "../utils/useSweetAlert";
import useUserStore from "../stores/UserStore";

// Set Selection Options
// const categoryOptions = [
// 	"Frac Services",
// 	"Cementing",
// 	"Drilling Tools Rental",
// 	"Inspection and Testing",
// 	"Containments",
// 	"Mud Management",
// 	"Generators, Engines",
// 	"Fluid Storage",
// 	"Rig Mats",
// 	"Rig Walking Systems",
// 	"Rig Moving",
// 	"Rig Cleaning",
// 	"Rig Maintenance",
// 	"Rig Decommissioning",
// 	"Rig Commissioning",
// 	"Rig Construction",
// 	"Rig Upgrades",
// 	"Rig Refurbishment",
// 	"Rig Inspection",
// 	"Rig Certification",
// ];

import { requestStatusOptions } from "../data/worksideOptions";

const RequestEditTemplate = (props) => {
	const data = props.rowData || {};
	const userId = useUserStore((state) => state.userID);
	const [customerChangeFlag, setCustomerChangeFlag] = useState(false);
	const [formData, setFormData] = useState({
		...data,
		requestcategory: "",
		requestname: "",
		quantity: 1,
		comment: "",
		vendortype: "MSA",
		vendorName: "",
		status: "OPEN",
		statusdate: new Date(),
		datetimerequested: new Date(),
		creationdate: new Date(),
		customername: "",
		customercontact: "",
		projectname: "",
		rigcompany: "",
		rigcompanycontact: "",
	});

	// Template state
	const [templates, setTemplates] = useState([]);
	const [isLoadingTemplates, setIsLoadingTemplates] = useState(false);
	const [showTemplateDialog, setShowTemplateDialog] = useState(false);
	const [showSaveTemplateDialog, setShowSaveTemplateDialog] = useState(false);
	const [newTemplateName, setNewTemplateName] = useState("");
	const [templateError, setTemplateError] = useState("");

	// Handle input changes
	const onChange = (args) => {
		console.log("onChange event:", args);

		if (args.value !== undefined) {
			// Handle dropdown selection
			const name = args.element?.id || args.target?.name;
			const value = args.itemData?.value || args.value;

			console.log("Setting form data for:", name, "with value:", value);

			setFormData((prev) => {
				const newData = { ...prev, [name]: value };
				console.log("New form data:", newData);
				return newData;
			});

			if (name === "requestcategory") {
				console.log("Filtering products for category:", value);
				FilterProducts(value);
			}
			if (name === "vendortype" && value === "SSR") {
				GetSSRVendors();
			}
			if (name === "customername") {
				setCustomerChangeFlag(true);
				// Clear customer contact when customer changes
				setFormData((prev) => ({ ...prev, customercontact: "" }));
			}
			if (name === "rigcompany") {
				// Clear rig company contact when rig company changes
				setFormData((prev) => ({ ...prev, rigcompanycontact: "" }));
			}
		}
	};

	const [isLoading, setIsLoading] = useState(false);
	const [customerOptions, setCustomerOptions] = useState([]);
	const [rigCompanyOptions, setRigCompanyOptions] = useState([]);
	const [rigCompanyContactOptions, setRigCompanyContactOptions] = useState([]);
	const [contactOptions, setContactOptions] = useState([]);
	const [projectOptions, setProjectOptions] = useState([]);
	const [readOnlyFlag, setReadOnlyFlag] = useState(false);
	const [msaVendorOptions, setMSAVendorOptions] = useState([]);
	const [allCategories, setAllCategories] = useState([]);
	const [filteredProducts, setFilteredProducts] = useState([]);
	const [products, setProducts] = useState([]);
	const [allProducts, setAllProducts] = useState([]);
	
	const vendorTypeOptions = ["MSA", "OPEN", "SSR"];

	// Get the project data
	const { data: projData } = useQuery({
		queryKey: ["projects"],
		queryFn: () => GetAllProjects(),
		refetchInterval: 10000,
		refetchOnReconnect: true,
		refetchOnWindowFocus: true,
		staleTime: 1000 * 60 * 10, // 10 minutes+
		retry: 3,
	});

	// Get the firms data
	const { data: firmData } = useQuery({
		queryKey: ["firms"],
		queryFn: () => GetAllFirms(),
		enabled: !!projData, // Only retrieve data if projData is available
		refetchInterval: 10000,
		refetchOnReconnect: true,
		refetchOnWindowFocus: true,
		staleTime: 1000 * 60 * 10, // 10 minutes
		retry: 3,
	});

	// Get the products data
	const { data: productsData, isLoading: isLoadingProducts } = useQuery({
		queryKey: ["products"],
		queryFn: () => GetProducts(),
		refetchInterval: 10000 * 60 * 10, // 10 minutes
		refetchOnReconnect: true,
		refetchOnWindowFocus: true,
		staleTime: 1000 * 60 * 10, // 10 minutes
		retry: 3,
	});

	// Get the contacts data
	const { data: contactsData } = useQuery({
		queryKey: ["contacts"],
		queryFn: () => GetAllContacts(),
		refetchInterval: 10000 * 60 * 10, // 10 minutes
		refetchOnReconnect: true,
		refetchOnWindowFocus: true,
		staleTime: 1000 * 60 * 10, // 10 minutes
		retry: 3,
	});

	// Update useEffect for initial product loading
	useEffect(() => {
		if (productsData?.data) {
			// console.log("Raw products data:", productsData.data);

			// Extract unique categories and sort them alphabetically
			const uniqueCategories = [
				...new Set(productsData.data.map((p) => p.categoryname)),
			]
				.filter(Boolean)
				.sort();

			// console.log("Unique categories:", uniqueCategories);

			// Format categories for dropdown
			const formattedCategories = uniqueCategories.map((category) => ({
				text: category,
				value: category,
			}));

			// console.log("Formatted categories:", formattedCategories);

			// Set all products and categories
			setAllProducts(productsData.data);
			setAllCategories(formattedCategories);
		}
	}, [productsData]); // Only depend on productsData

	// Separate useEffect for filtered products
	useEffect(() => {
		if (allProducts.length > 0 && formData.requestcategory) {
			const filteredProducts = allProducts
				.filter((p) => p.categoryname === formData.requestcategory)
				.map((p) => ({
					text: p.productname,
					value: p.productname,
				}));
			setFilteredProducts([...new Set(filteredProducts)]);
		} else {
			setFilteredProducts([]);
		}
	}, [allProducts, formData.requestcategory]);

	// Update FilterProducts function to be memoized
	const FilterProducts = useCallback(
		(selectedCategory) => {
			// console.log("FilterProducts called with category:", selectedCategory);
			try {
				if (!selectedCategory || !allProducts?.length) {
					console.log("No category selected or no products available");
					setFilteredProducts([]);
					return;
				}

				// console.log("All products:", allProducts);
				const filtered = allProducts
					.filter((p) => p.categoryname === selectedCategory)
					.map((p) => ({
						text: p.productname,
						value: p.productname,
					}));

				// console.log("Filtered products:", filtered);
				const uniqueFiltered = [...new Set(filtered.map(JSON.stringify))].map(
					JSON.parse,
				);
				setFilteredProducts(uniqueFiltered);
			} catch (error) {
				console.error("Error filtering products:", error);
				setFilteredProducts([]);
			}
		},
		[allProducts],
	);

	const getCustomers = useCallback((firms) => {
		if (firms === undefined || firms === null) return [];
		return firms.data.filter((firm) => firm.type === "CUSTOMER");
	}, []);

	const getRigCompanies = useCallback((firms) => {
		if (firms === undefined || firms === null) return [];
		return firms.data.filter((firm) => firm.type === "RIGCOMPANY");
	}, []);

	useEffect(() => {
		if (firmData === undefined || firmData === null) return;

		// Get Customers
		const customerResult = getCustomers(firmData);
		const customers = customerResult?.map((r) => ({
			text: r.name,
			value: r.name,
		}));
		console.log("Customer options:", customers);
		setCustomerOptions(customers);

		// Get Rig Companies
		const rigResult = getRigCompanies(firmData);
		const rigCompanies = rigResult?.map((r) => ({
			text: r.name,
			value: r.name,
		}));
		console.log("Rig company options:", rigCompanies);
		setRigCompanyOptions(rigCompanies);

		// Get Projects
		if (projData?.data) {
			const projects = projData.data.map((p) => ({
				text: p.projectname,
				value: p.projectname,
			}));
			console.log("Project options:", projects);
			setProjectOptions(projects);
		}

		// Debug log for dropdown data
		console.log("Dropdown data check:", {
			customerOptions: customers,
			rigCompanyOptions: rigCompanies,
			projectOptions: projData?.data?.map((p) => ({
				text: p.projectname,
				value: p.projectname,
			})),
			formData: formData,
		});
	}, [firmData, projData, getCustomers, getRigCompanies]);

	// Memoize filterContactsByFirm
	const filterContactsByFirm = useCallback((contacts, firm) => {
		return contacts?.filter((contact) => contact?.firm === firm);
	}, []);

	// Get Customer Contacts
	useEffect(() => {
		if (contactsData === undefined || contactsData === null) return;

		const contacts = contactsData.data;
		const result = filterContactsByFirm(contacts, formData.customername);
		const contactsList = result.map((r) => ({
			text: r.username,
			value: r.username,
		}));
		setContactOptions(contactsList);
		setCustomerChangeFlag(false);
	}, [contactsData, formData.customername, filterContactsByFirm]);

	// Get Rig Company Contacts
	useEffect(() => {
		if (contactsData === undefined || contactsData === null) return;
		const result = contactsData.data.filter(
			(contact) => contact.firm === formData.rigcompany,
		);
		// Format contacts for dropdown
		const contacts = result.map((r) => ({
			text: r.username,
			value: r.username,
		}));
		setRigCompanyContactOptions(contacts);
	}, [contactsData, formData.rigcompany]);

	const extractProducts = (response) => {
		// Check if status is 200 and extract the data array
		if (response.length > 0 && response[0].status === 200) {
			return response[0].data;
		}
		return [];
	};
	const GetSSRVendors = async () => {
		if (data.requestcategory === undefined || data.requestname === undefined) {
			await showErrorDialog("Please select a Request Category and Request Name!");
			return;
		}
		GetSupplierProductsByProduct().then((response) => {
			const suppliers = extractProducts(response);
			const filteredSuppliers = suppliers.filter((s) => {
				if (
					s.category === data.requestcategory &&
					s.product === data.requestname
				) {
					return true;
				}
				return false;
			});
			if (filteredSuppliers.length === 0) {
				showErrorDialog("No Sole Source Vendors/Suppliers Found!");
			} else {
				const suppliers = [
					...new Set(filteredSuppliers.map((s) => s.supplier)),
				];
				setMSAVendorOptions(suppliers);
			}
		});
	};


	useEffect(() => {
		if (data.isAdd) {
			setFormData((prev) => ({
				...prev,
				datetimerequested: new Date(),
				creationdate: new Date(),
				status: "OPEN",
				statusdate: new Date(),
			}));
			setReadOnlyFlag(false);
		} else {
			setReadOnlyFlag(true);
			GetProducts();
			if (formData.requestcategory) {
				FilterProducts(formData.requestcategory);
			}
		}
	}, [data.isAdd, FilterProducts, formData.requestcategory]);

	// Template handling functions
	const fetchTemplates = useCallback(async () => {
		// if (!userId) return;
		// TODO: Remove this once we have a user ID
		const userId = "679d76fde33b65f7d45013e4";
		setIsLoadingTemplates(true);
		try {
			const response = await getRequestTemplates(userId);
			if (!response?.data) {
				throw new Error("No templates data received");
			}
			setTemplates(response.data);
		} catch (error) {
			console.error("Error fetching templates:", error);
			setTemplateError("Failed to load templates");
		} finally {
			setIsLoadingTemplates(false);
		}
	}, []); // Remove userId from dependencies since it's hardcoded for now

	const handleTemplateSelection = useCallback(
		async (template) => {
			try {
				if (!template?.category || !template?.product) {
					throw new Error("Invalid template data");
				}

				// Update form data first
				setFormData((prev) => ({
					...prev,
					requestcategory: template.category,
					requestname: template.product,
					quantity: Number.isInteger(template.quantity) ? template.quantity : 1,
					comment: template.comment || "",
					vendortype: template.preferredVendorType || "MSA",
					vendorName: template.preferredVendor || "",
				}));

				// Filter products for the selected category
				FilterProducts(template.category);

				// Handle vendor type
				const vendorTypeDropdown =
					document.getElementById("vendortype")?.ej2_instances?.[0];
				if (vendorTypeDropdown) {
					switch (template.preferredVendorType) {
						case "SSR":
							if (template.preferredVendor) {
								const response = await GetSupplierProductsByProduct(
									template.category,
									template.product,
								);
								const suppliers = response?.data?.filter(
									(s) =>
										s.category === template.category &&
										s.product === template.product,
								);

								if (suppliers?.length > 0) {
									setMSAVendorOptions(suppliers.map((s) => s.supplier));
									vendorTypeDropdown.value = "SSR";

									// Set vendor name after SSR is selected
									setTimeout(() => {
										const vendorNameDropdown =
											document.getElementById("vendorName")?.ej2_instances?.[0];
										if (vendorNameDropdown) {
											vendorNameDropdown.value = template.preferredVendor;
										}
									}, 100);
								}
							}
							break;
						case "OPEN":
							vendorTypeDropdown.value = "OPEN";
							break;
						default:
							vendorTypeDropdown.value = "MSA";
					}
				}

				setShowTemplateDialog(false);
				await showSuccessDialogWithTimer("Template applied successfully");
			} catch (error) {
				console.error("Error applying template:", error);
				await showErrorDialog(`Failed to apply template: ${error.message}`);
			}
		},
		[FilterProducts],
	);

	const handleSaveTemplate = async () => {
		try {
			if (!newTemplateName.trim()) {
				throw new Error("Template name is required");
			}

			const existingTemplate = templates.find(
				(t) => t.name.toLowerCase() === newTemplateName.toLowerCase(),
			);

			if (existingTemplate) {
				throw new Error("Template name already exists");
			}

			const templateData = {
				name: newTemplateName,
				description: `${data.requestcategory} - ${data.requestname} template`,
				category: data.requestcategory,
				product: data.requestname,
				comment: data.comment,
				quantity: data.quantity,
				preferredVendorType: data.vendortype,
				preferredVendor: data.vendortype === "SSR" ? data.vendorName : null,
				createdBy: userId,
			};

			const response = await createRequestTemplate(templateData);
			if (!response?.data) {
				throw new Error("Failed to create template");
			}

			setShowSaveTemplateDialog(false);
			setNewTemplateName("");
			setTemplateError("");
			await showSuccessDialogWithTimer("Template saved successfully");
			await fetchTemplates();
		} catch (error) {
			console.error("Save template error:", error);
			setTemplateError(error.message);
			await showErrorDialog(error.message);
		}
	};

	// Update the template dialog to ensure it shows templates
	const renderTemplateDialog = () =>
		showTemplateDialog && (
			<div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
				<div className="bg-white p-6 rounded-lg w-96">
					<div className="flex justify-between items-center mb-4">
						<h2 className="text-xl font-bold">Select Template</h2>
						<button
							type="button"
							className="bg-gray-200 hover:bg-gray-300 text-black px-3 py-1 rounded"
							onClick={() => setShowTemplateDialog(false)}
						>
							×
						</button>
					</div>
					{isLoadingTemplates ? (
						<div className="text-center">Loading templates...</div>
					) : templateError ? (
						<div className="text-red-500">{templateError}</div>
					) : templates.length === 0 ? (
						<div className="text-center text-gray-600">
							No templates available
						</div>
					) : (
						<div className="max-h-60 overflow-y-auto">
							{templates.map((template) => (
								<button
									type="button"
									key={template._id}
									className="w-full text-left p-2 hover:bg-gray-100 cursor-pointer border-b border-gray-200"
									onClick={() => handleTemplateSelection(template)}
								>
									<h3 className="font-bold">{template.name}</h3>
									<p className="text-sm text-gray-600">
										{template.description}
									</p>
								</button>
							))}
						</div>
					)}
				</div>
			</div>
		);

	const renderSaveTemplateDialog = () =>
		showSaveTemplateDialog && (
			<div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
				<div className="bg-white p-6 rounded-lg w-96">
					<div className="flex justify-between items-center mb-4">
						<h2 className="text-xl font-bold">Save as Template</h2>
						<button
							type="button"
							className="bg-gray-200 hover:bg-gray-300 text-black px-3 py-1 rounded"
							onClick={() => setShowSaveTemplateDialog(false)}
						>
							×
						</button>
					</div>
					<input
						type="text"
						className="w-full p-2 border rounded mb-4"
						placeholder="Template Name"
						value={newTemplateName}
						onChange={(e) => setNewTemplateName(e.target.value)}
					/>
					{templateError && (
						<div className="text-red-500 mb-4">{templateError}</div>
					)}
					<div className="flex justify-end gap-4">
						<button
							type="button"
							className="bg-gray-500 text-white px-4 py-2 rounded"
							onClick={() => setShowSaveTemplateDialog(false)}
						>
							Cancel
						</button>
						<button
							type="button"
							className="bg-green-500 text-white px-4 py-2 rounded"
							onClick={handleSaveTemplate}
						>
							Save
						</button>
					</div>
				</div>
			</div>
		);

	// Load templates on initial render
	useEffect(() => {
		fetchTemplates();
	}, [fetchTemplates]);

	// Add this debug log before the return statement
	console.log("Current formData:", formData);
	console.log("Dropdown states:", {
		customerOptions,
		rigCompanyOptions,
		projectOptions,
		filteredProducts,
		allCategories,
	});

	return (
		<div className="flex justify-center items-center bg-white">
			<style>
				{`
					.e-custom {
						width: 100%;
						min-height: 40px;
						background-color: white;
						border: 1px solid #ddd;
						border-radius: 4px;
						padding: 8px;
					}
					.e-custom .e-input {
						height: 100%;
						padding: 8px;
					}
					.e-custom .e-input-group {
						border: none;
					}
					.e-custom .e-input-group-icon {
						background-color: transparent;
					}
					.e-custom .e-input-group-icon.e-ddl-icon {
						background-color: transparent;
					}
					.e-custom .e-input-group-icon.e-ddl-icon:hover {
						background-color: #f5f5f5;
					}
					.e-custom .e-input-group-icon.e-ddl-icon:active {
						background-color: #e0e0e0;
					}
				`}
			</style>
			{isLoading && (
				<div className="absolute top-[50%] left-[50%]">
					<div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-green-500" />
				</div>
			)}
			{renderTemplateDialog()}
			{renderSaveTemplateDialog()}
			<div className="w-[600px] mx-[4px] space-y-2">
				{/* Template buttons at the top */}
				<div className="flex justify-end gap-2 mb-4">
					<button
						type="button"
						className="bg-green-500 hover:drop-shadow-xl hover:bg-light-gray p-2 rounded-lg items-center justify-center border-2 border-solid border-black border-r-4 border-b-4 font-bold"
						onClick={async () => {
							await fetchTemplates();
							setShowTemplateDialog(true);
						}}
					>
						Load Template
					</button>
					<button
						type="button"
						className="bg-green-500 hover:drop-shadow-xl hover:bg-light-gray p-2 rounded-lg items-center justify-center border-2 border-solid border-black border-r-4 border-b-4 font-bold"
						onClick={() => setShowSaveTemplateDialog(true)}
					>
						Save as Template
					</button>
				</div>

				{/* Row 1 */}
				<div className="flex gap-4">
					{/* Input 1 */}
					<div className="flex flex-col w-1/2">
						<label
							className={`${readOnlyFlag ? "text-red-500" : "text-black"} text-sm font-medium mb-1`}
							htmlFor="field1"
						>
							Request Category
						</label>
						<DropDownListComponent
							id="requestcategory"
							name="requestcategory"
							dataSource={allCategories}
							fields={{ text: "text", value: "value" }}
							value={formData.requestcategory}
							placeholder="Select Category"
							popupHeight="300px"
							enabled={true}
							onChange={onChange}
							allowFiltering={true}
							filterType="Contains"
							showSelectAll={false}
							showDropDownIcon={true}
							showClearButton={true}
							floatLabelType="Auto"
							cssClass="e-custom"
							index={allCategories.findIndex(
								(cat) => cat.value === formData.requestcategory,
							)}
						/>
					</div>
					{/* Input 2 */}
					<div className="flex flex-col w-1/2">
						<label
							className={`${readOnlyFlag ? "text-red-500" : "text-black"} text-sm font-medium mb-1`}
							htmlFor="field2"
						>
							Request Name
						</label>
						<DropDownListComponent
							id="requestname"
							name="requestname"
							dataSource={filteredProducts}
							fields={{ text: "text", value: "value" }}
							value={formData.requestname}
							placeholder="Select Request"
							popupHeight="300px"
							enabled={true}
							onChange={onChange}
							allowFiltering={true}
							filterType="Contains"
						/>
					</div>
				</div>
				{/* Row 2 */}
				<div className="flex gap-4">
					{/* Input 3 */}
					<div className="flex flex-col w-1/2">
						<label
							className={`${readOnlyFlag ? "text-red-500" : "text-black"} text-sm font-medium mb-1`}
							htmlFor="field3"
						>
							Customer
						</label>
						<DropDownListComponent
							id="customername"
							name="customername"
							dataSource={customerOptions}
							fields={{ text: "text", value: "value" }}
							value={formData.customername}
							placeholder="Select Customer"
							onChange={(args) => {
								console.log("Customer dropdown change:", args);
								onChange(args);
							}}
							cssClass="e-custom"
						/>
					</div>
					{/* Input 4 */}
					<div className="flex flex-col w-1/2">
						<label className="text-sm font-medium mb-1" htmlFor="field4">
							Customer Contact
						</label>
						<DropDownListComponent
							id="customercontact"
							name="customercontact"
							dataSource={contactOptions}
							fields={{ text: "text", value: "value" }}
							value={formData.customercontact}
							placeholder="Select Customer Contact"
							required={true}
							onChange={onChange}
						/>
					</div>
				</div>
				{/* Row 3 */}
				<div className="flex gap-4">
					{/* Input 5 */}
					<div className="flex flex-col w-full">
						<label
							className={`${readOnlyFlag ? "text-red-500" : "text-black"} text-sm font-medium mb-1`}
							htmlFor="field5"
						>
							Project Name
						</label>
						<DropDownListComponent
							id="projectname"
							name="projectname"
							dataSource={projectOptions}
							fields={{ text: "text", value: "value" }}
							value={formData.projectname}
							placeholder="Select Project"
							onChange={(args) => {
								console.log("Project dropdown change:", args);
								onChange(args);
							}}
							cssClass="e-custom"
						/>
					</div>
				</div>
				{/* Row 4 */}
				<div className="flex gap-4">
					{/* Input 6 */}
					<div className="flex flex-col w-1/2">
						<label
							className={`${readOnlyFlag ? "text-red-500" : "text-black"} text-sm font-medium mb-1`}
							htmlFor="field6"
						>
							Rig Company
						</label>
						<DropDownListComponent
							id="rigcompany"
							name="rigcompany"
							dataSource={rigCompanyOptions}
							fields={{ text: "text", value: "value" }}
							value={formData.rigcompany}
							placeholder="Select Rig Company"
							onChange={(args) => {
								console.log("Rig Company dropdown change:", args);
								onChange(args);
							}}
							cssClass="e-custom"
						/>
					</div>
					{/* Input 7 */}
					<div className="flex flex-col w-1/2">
						<label className="text-sm font-medium mb-1" htmlFor="field7">
							Rig Company Contact
						</label>
						<DropDownListComponent
							id="rigcompanycontact"
							name="rigcompanycontact"
							dataSource={rigCompanyContactOptions}
							fields={{ text: "text", value: "value" }}
							value={formData.rigcompanycontact}
							placeholder="Select Rig Company Contact"
							required={true}
							onChange={onChange}
						/>
					</div>
				</div>
				{/* Row 5 */}
				<div className="flex gap-4">
					{/* Input 8 */}
					<div className="flex flex-col w-1/3">
						<label
							className={`${readOnlyFlag ? "text-red-500" : "text-black"} text-sm font-medium mb-1`}
							htmlFor="field8"
						>
							Request Date
						</label>
						<DatePickerComponent
							id="creationdate"
							name="creationdate"
							value={data.creationdate}
							placeholder="Select Request Date"
							required={true}
							onChange={onChange}
							readonly={readOnlyFlag}
						/>
					</div>
					{/* Input 9 */}
					<div className="flex flex-col w-1/3">
						<label
							className={`${!data.isAdd ? "text-red-500" : "text-black"} text-sm font-medium mb-1`}
							htmlFor="field9"
						>
							Date/Time Requested
						</label>
						<DateTimePickerComponent
							id="datetimerequested"
							name="datetimerequested"
							value={data.datetimerequested}
							placeholder="Select Date/Time Requested"
							disabled={false}
							onChange={onChange}
						/>
					</div>
					{/* Input 10 */}
					<div className="flex flex-col w-1/3">
						<label
							className={`${!data.isAdd ? "text-red-500" : "text-black"} text-sm font-medium mb-1`}
							htmlFor="field10"
						>
							Quantity
						</label>
						<NumericTextBoxComponent
							id="quantity"
							value={data.quantity}
							placeholder="Enter Quantity"
							showSpinButton={false}
							decimals={2}
							format="n2"
							required={true}
						/>
					</div>
				</div>
				{/* Row 6 */}
				<div className="flex gap-4">
					{/* Input 11 */}
					<div className="flex flex-col w-1/2">
						<label className="text-sm font-medium mb-1" htmlFor="field11">
							Vendor Type
						</label>
						<DropDownListComponent
							id="vendortype"
							name="vendortype"
							dataSource={vendorTypeOptions}
							value={data.vendortype}
							placeholder="Select Vendor Type"
							required={true}
							onChange={onChange}
						/>
					</div>
					{/* Input 12 */}
					<div className="flex flex-col w-1/2">
						<label
							className={"text-black text-sm font-medium mb-1"}
							htmlFor="field12"
						>
							SSR Vendor
						</label>
						<DropDownListComponent
							id="vendorName"
							name="vendorName"
							dataSource={msaVendorOptions}
							value={data.vendorName}
							placeholder="Select Sole Source Vendor"
							required={false}
							// readonly={data.vendorType !== "SSR"}
							onChange={onChange}
						/>
					</div>
				</div>
				{/* Row 7 */}
				<div className="flex gap-4">
					{/* Input 5 */}
					<div className="flex flex-col w-full">
						<label className="text-sm font-medium mb-1" htmlFor="field13">
							Comment
						</label>
						<input
							type="text"
							id="comments"
							name="comments"
							defaultValue={data?.comment}
							className="e-input"
							placeholder="Enter Comments"
							onChange={onChange}
						/>
					</div>
				</div>
				{/* Row 8 */}
				<div className="flex gap-4">
					{/* Input 11 */}
					<div className="flex flex-col w-1/2">
						<label className="text-sm font-medium mb-1" htmlFor="field14">
							Status
						</label>
						<DropDownListComponent
							id="status"
							name="status"
							dataSource={requestStatusOptions}
							value={data.status}
							placeholder="Select Status"
							required={true}
							onChange={onChange}
						/>
					</div>
					{/* Input 12 */}
					<div className="flex flex-col w-1/2">
						<label
							className={"text-black text-sm font-medium mb-1"}
							htmlFor="field15"
						>
							Status Date
						</label>
						<DatePickerComponent
							id="statusdate"
							name="statusdate"
							value={data.statusdate}
							placeholder="Select Status Date"
							required={true}
							onChange={onChange}
						/>
					</div>
				</div>
				{/* End of Input Fields */}

				{/* Bottom button container */}
				<div className="flex justify-between items-center mt-4 pt-4 border-t border-gray-200">
					{/* Remove the template buttons from here */}
				</div>
			</div>
		</div>
	);
};

export default RequestEditTemplate;

