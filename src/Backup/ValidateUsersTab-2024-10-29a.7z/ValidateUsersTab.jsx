/* eslint-disable */
import React, { useEffect, useState, useRef } from "react";
import {
	GridComponent,
	ColumnsDirective,
	ColumnDirective,
	Selection,
	Edit,
	Filter,
	Inject,
	Page,
	Toolbar,
	Resize,
	Freeze,
} from "@syncfusion/ej2-react-grids";
import { DialogComponent } from "@syncfusion/ej2-react-popups";
import {
	Button,
	Dialog,
	DialogTitle,
	DialogContent,
	DialogContentText,
	DialogActions,
	Stack,
	IconButton,
	TextField,
} from "@mui/material";
import Select from "react-select";

// import { CloseIcon } from "@mui/icons-material";
import { closest } from "@syncfusion/ej2-base";
// import { toast } from "react-toastify";
// import { MaskedTextBox } from "@syncfusion/ej2-inputs";
// import { DataManager, Query } from "@syncfusion/ej2-data";
import { useStateContext } from "../contexts/ContextProvider";
import UserValidationModal from "../components/UserValidationModal";

import "../index.css";
import "../App.css";
import { Save } from "@mui/icons-material";
import { dialog, menu } from "@material-tailwind/react";

// const apiUrl = process.env.REACT_APP_API_URL;

const gridPageSize = 10;

const ValidateUsersTab = () => {
	const [isLoading, setIsLoading] = useState(false);
	const [showDialog, setShowDialog] = useState(false);

	let usersGridRef = useRef(null);
	const [userList, setUserList] = useState(null);
	const [insertFlag, setInsertFlag] = useState(false);
	const editOptions = {
		allowEditing: true,
		allowUpdating: true,
		allowAdding: true,
		allowDeleting: true,
		mode: "Dialog",
	};

	const toolbarOptions = ["Add", "Update", "Edit", "Delete"];
	const [selectedRecord, setSelectedRecord] = useState(null);
	const settings = { mode: "Row" };
	const position = { X: "center", Y: "center" };
	const dialogAnimationSettings = {
		effect: "FlipX",
		duration: 3000,
		delay: 1000,
	};
	const { currentColor } = useStateContext();

	const [formData, setFormData] = useState({
		firstname: "Mike",
		lastname: "Hunt",
		nickname: "",
		company: "",
		accesslevel: "",
		email: "mhunt@gmail.com",
		cellnumber: "",
		status: "",
		comment: "",
	});

	const buttons = [
		{
			buttonModel: {
				content: "SAVE",
				cssClass: "e-flat",
				// isPrimary: true,
				location: "center",
			},
			click: () => {
				setShowDialog(false);
			},
		},
		{
			buttonModel: {
				content: "Cancel",
				cssClass: "e-flat",
			},
			click: () => {
				setShowDialog(false);
			},
		},
	];

	useEffect(() => {
		const fetchContacts = async () => {
			setIsLoading(true);
			const response = await fetch(
				`${process.env.REACT_APP_MONGO_URI}/api/user`,
			);
			const json = await response.json();
			setUserList(json);
			setIsLoading(false);
		};
		fetchContacts();
	}, []);

	const usersActionComplete = async (args) => {
		if (!usersGridRef) return;
		if (
			args.requestType === "beginEdit" ||
			args.requestType === "add" ||
			args.requestType === "update" ||
			args.requestType === "save" ||
			args.requestType === "delete"
		) {
			if (args.requestType === "beginEdit" || args.requestType === "add") {
				const { dialog } = args;
				dialog.header = "Workside Users";
			}
			if (args.requestType === "add") {
				// set insert flag
				setInsertFlag(true);
			}
			if (args.requestType === "update") {
				// set insert flag
				setInsertFlag(false);
			}
			if (args.requestType === "save") {
				// Save or Update Data
				const { data } = args;
				window.alert(`Request Type: ${args.requestType}`);
				window.alert(`User args: ${JSON.stringify(data)}`);
				window.alert(`Insert Flag: ${insertFlag}`);

				if (insertFlag === true) {
					const response = await fetch(
						`${process.env.REACT_APP_MONGO_URI}/api/user/`,
						{
							method: "POST",
							body: JSON.stringify(data),
							headers: {
								"Content-Type": "application/json",
							},
						},
					);

					const json = await response.json();
					window.alert(`User Response: ${JSON.stringify(json)}`);
					if (response.ok) {
						// console.log('Insert: ' + JSON.stringify(args.data));
						// dispatch({ type: 'CREATE_PRODUCT', payload: json });
					}
				} else {
					// dispatch({ type: 'CREATE_PRODUCT', payload: args.data });
					// console.log('Update: ' + JSON.stringify(args.data));
				}
				setInsertFlag(false);
			}
			if (args.requestType === "delete") {
				// Delete Data
				handleUserDelete();
				setInsertFlag(false);
			}
		}
	};
	const rowSelectedUser = () => {
		if (usersGridRef) {
			/** Get the selected row indexes */
			const selectedrowindex = usersGridRef.getSelectedRowIndexes();
			/** Get the selected records. */
			setSelectedRecord(userList[selectedrowindex]._id);
			// eslint-disable-next-line prefer-template
			// setEmptyFields([]);
		}
	};

	const onUserLoad = () => {
		const gridElement = document.getElementById("userGridElement");
		if (gridElement?.ej2_instances[0]) {
			const gridInstance = gridElement.ej2_instances[0];
			gridInstance.pageSettings.pageSize = gridPageSize;
			gridInstance.pageSettings.frozenColumns = 2;
			gridInstance.pageSettings.freeze = true;
		}
	};

	const FilterOptions = {
		type: "Menu",
	};

	const gridTemplate = (props) => (
		<div>
			<button
				type="button"
				style={{
					background: currentColor,
					color: "white",
					padding: "5px",
					borderRadius: "5%",
				}}
				className="userData"
			>
				Validate
			</button>
		</div>
	);

	const recordClick = (args) => {
		if (args.target.classList.contains("userData")) {
			const rowObj = usersGridRef.getRowObjectFromUID(
				closest(args.target, ".e-row").getAttribute("data-uid"),
			);

			// const selectedrowindex = requestGrid.getSelectedRowIndexes();
			setSelectedRecord(rowObj._id);
			setShowDialog(true);
		}
	};

	const dialogClose = () => {
		setShowDialog(false);
	};

	const dialogOpen = () => {
		setShowDialog(true);
	};

	const SaveUserValidation = () => {
		// Save User Validation
		window.alert(`Validation Data: ${JSON.stringify(formData)}`);
	};

	const dialogButtonFormat =
		"bg-green-200 text-black p-1 rounded-lg w-24 items-center justify-center border-2 border-solid border-black border-r-4 border-b-4 text-xs";

	const footerTemplate = () => {
		return (
			<div className="flaw-row gap-3 space-x-3">
				<button
					id="sendButton"
					type="button"
					className={dialogButtonFormat}
					// className="e-control e-btn e-primary"
					data-ripple="true"
					onClick={SaveUserValidation}
				>
					SAVE
				</button>
				<button
					id="sendButton"
					type="button"
					className={dialogButtonFormat}
					// className="e-control e-btn e-primary"
					data-ripple="true"
					onClick={dialogClose}
				>
					Cancel
				</button>
			</div>
		);
	};

	return (
		<div className="absolute top-[50px] left-[20px] w-[100%] flex flex-row items-center justify-start">
			<GridComponent
				id="userGridElement"
				dataSource={userList}
				actionComplete={usersActionComplete}
				allowSelection
				allowFiltering
				allowPaging
				allowResizing
				filterSettings={FilterOptions}
				selectionSettings={settings}
				toolbar={toolbarOptions}
				rowSelected={rowSelectedUser}
				recordClick={recordClick}
				editSettings={editOptions}
				enablePersistence
				// pageSize={gridPageSize}
				// frozenColumns={2}
				load={onUserLoad}
				width="95%"
				ref={(g) => {
					usersGridRef = g;
				}}
			>
				<ColumnsDirective>
					<ColumnDirective
						field="_id"
						headerText="Id"
						textAlign="Left"
						width="50"
						isPrimaryKey
						allowEditing={false}
						visible={false}
					/>
					<ColumnDirective
						headerText="Validate"
						textAlign="Center"
						width="80"
						template={gridTemplate}
						allowEditing="false"
					/>
					<ColumnDirective
						field="firstName"
						headerText="First"
						textAlign="Left"
						width="125"
					/>
					<ColumnDirective
						field="lastName"
						headerText="Last"
						textAlign="Left"
						width="125"
					/>
					<ColumnDirective
						field="company"
						headerText="Company"
						editType="dropdownedit"
						textAlign="Left"
						width="100"
					/>
					<ColumnDirective
						field="email"
						headerText="email"
						textAlign="Left"
						width="100"
					/>
					<ColumnDirective
						field="password"
						headerText="Password"
						textAlign="Left"
						width="100"
					/>
					<ColumnDirective
						field="isEmailValid"
						headerText="Email Validated?"
						textAlign="Left"
						width="140"
					/>
					<ColumnDirective
						field="isUserValidated"
						headerText="User Validated?"
						textAlign="Left"
						width="100"
					/>
					{/* <ColumnDirective
						field="status"
						headerText="Status"
						editType="dropdownedit"
						textAlign="Left"
						width="100"
					/>
					<ColumnDirective
						field="statusdate"
						headerText="Date"
						type="date"
						editType="datepickeredit"
						format="MM/dd/yyy"
						textAlign="Right"
						width="140"
					/> */}
					{/* <ColumnDirective
						field="comment"
						headerText="Comment"
						textAlign="Left"
						width="200"
					/> */}
				</ColumnsDirective>
				<Inject
					services={[Selection, Edit, Filter, Page, Toolbar, Resize, Freeze]}
				/>
			</GridComponent>
			<div className="items-center">
				{showDialog && (
					<MaterialValidationModal
						recordID={selectedRecord}
						open={showDialog}
						onOK={dialogClose}
						onClose={dialogClose}
						data={formData}
						onUpdateData={setFormData}
					/>

					// <DialogComponent
					// 	id="userValidationDialog"
					// 	header="Workside User Validation"
					// 	visible={showDialog}
					// 	showCloseIcon
					// 	allowDragging={true}
					// 	width="400px"
					// 	height="700px"
					// 	open={dialogOpen}
					// 	close={dialogClose}
					// 	position={position}
					// 	isModal={true}
					// 	// buttons={buttons}
					// 	// animationSettings={dialogAnimationSettings}
					// 	// dialogAnimationSettings={dialogAnimationSettings}
					// 	closeOnEscape
					// 	footerTemplate={footerTemplate}
					// 	// footerTemplate={
					// 	// 	<div style={{ display: "flex", justifyContent: "flex-end" }}>
					// 	// 		<button type="button">Cancel</button>
					// 	// 		<button type="button">Save</button>
					// 	// 	</div>
					// 	// }
					// >
					// 	<ValidationModal
					// 		// <UserValidationModal
					// 		recordID={selectedRecord}
					// 		open={showDialog}
					// 		// onOK={dialogClose}
					// 		// onClose={dialogClose}
					// 		data={formData}
					// 		onUpdateData={setFormData}
					// 	/>
					// </DialogComponent>
				)}
			</div>
		</div>
	);
};

const MaterialValidationModal = ({
	recordID,
	open,
	onOK,
	onClose,
	data,
	onUpdateData,
}) => {
	if (!open || !recordID) return null;

	const [showRecord, setShowRecord] = useState(false);
	const [statusMenuIsOpen, setStatusMenuIsOpen] = useState(false);
	const [companyMenuIsOpen, setCompanyMenuIsOpen] = useState(false);
	const [accessMenuIsOpen, setAccessMenuIsOpen] = useState(false);

	const handleStatusMenuOpen = () => {
		setStatusMenuIsOpen(true);
	};

	const handleStatusMenuClose = () => {
		setStatusMenuIsOpen(false);
	};

	const handleCompanyMenuOpen = () => {
		setCompanyMenuIsOpen(true);
	};

	const handleCompanyMenuClose = () => {
		setCompanyMenuIsOpen(false);
	};
	const handleAccessMenuOpen = () => {
		setAccessMenuIsOpen(true);
	};

	const handleAccessMenuClose = () => {
		setAccessMenuIsOpen(false);
	};
	// const [data, setData] = useState({
	// 	firstname: "",
	// 	lastname: "",
	// 	nickname: "",
	// 	company: "",
	// 	accesslevel: "",
	// 	email: "",
	// 	cellnumber: "",
	// 	status: "",
	// 	comment: "",
	// });
	const handleChange = ({ currentTarget: input }) => {
		setData({ ...data, [input.name]: input.value });
	};
	const showID = () => {
		setShowRecord(!showRecord);
	};
	const inputFormat =
		"bg-gray-200 w-[100%] pt-1 pb-1 flex items-center mb-1 rounded-8xs shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] box-border border-[1px] border-solid border-black border-r-2 border-b-2 px-1";

	// const onOK = () => {
	// 	// Save User Validation
	// 	window.alert(`Validation Data: ${JSON.stringify(data)}`);
	// };

	const handleDataChange = ({ currentTarget: input }) => {
		// setData({ ...data, [input.name]: input.value });

		const updatedData = { ...data, [input.name]: input.value };
		onUpdateData(updatedData);
		// window.alert(`Data: ${JSON.stringify(updatedData)}`);
	};

	const onSaveData = () => {
		// Save User Validation
		// window.alert(`Validation Data: ${JSON.stringify(data)}`);
		onClose();
	};

	const accessLevelOptions = [
		{ value: "ADMIN", label: "ADMIN" },
		{ value: "GUEST", label: "GUEST" },
		{ value: "STANDARD", label: "STANDARD" },
	];

	const companyOptions = [
		{ value: "BERRY", label: "BERRY" },
		{ value: "CHEVRON", label: "CHEVRON" },
		{ value: "CRC", label: "CRC" },
	];

	const statusOptions = [
		{ value: "ACTIVE", label: "ACTIVE" },
		{ value: "IN-ACTIVE", label: "IN-ACTIVE" },
	];

	return (
		// <Dialog open={open} aria-labelledby="dialog-title" aria-describedby="dialog-content">
		<Dialog open={open} aria-labelledby="dialog-title">
			<DialogTitle id="dialog-title">Workside User Validation</DialogTitle>
			{/* <IconButton style={{ float: "right" }} onClick={onClose}>
				<CloseIcon />
			</IconButton> */}
			<DialogContent>
				{/* <DialogContentText id="dialog-content">Sample Text</DialogContentText> */}
				<Stack spacing={2} margin={2}>
					<TextField
						variant="outlined"
						label="First Name"
						name="firstname"
						value={data.firstname}
						onChange={handleDataChange}
					/>
					<TextField
						variant="outlined"
						label="Last Name"
						name="lastname"
						value={data.lastname}
						onChange={handleDataChange}
					/>
					<TextField
						variant="outlined"
						label="Nickname"
						name="nickname"
						value={data.nickname}
						onChange={handleDataChange}
					/>
					<div style={{ width: "300px" }}>
						<p className="text-sm font-bold">Company</p>
						<Select
							className="basic-single"
							classNamePrefix="select"
							// defaultValue={selectedOption}
							isDisabled={false}
							// onChange={handleSelectionChange}
							// isLoading={isLoading}
							// isClearable={isClearable}
							// isRtl={isRtl}
							// isSearchable={isSearchable}
							// menuIsOpen={true}
							onMenuOpen={handleCompanyMenuOpen}
							onMenuClose={handleCompanyMenuClose}
							name="company"
							options={companyOptions}
						/>
					</div>
					{companyMenuIsOpen === false && (
						<>
							<div style={{ width: "300px" }}>
								<p className="text-sm font-bold">Access Level</p>
								<Select
									className="basic-single"
									classNamePrefix="select"
									// defaultValue={selectedOption}
									isDisabled={false}
									// onChange={handleSelectionChange}
									// isLoading={isLoading}
									// isClearable={isClearable}
									// isRtl={isRtl}
									// isSearchable={isSearchable}
									onMenuOpen={handleAccessMenuOpen}
									onMenuClose={handleAccessMenuClose}
									name="accesslevel"
									options={accessLevelOptions}
								/>
							</div>
							<TextField
								variant="outlined"
								label="Email"
								name="email"
								value={data.email}
								onChange={handleDataChange}
							/>
						</>
					)}{" "}
					{companyMenuIsOpen === true && (
						<div>
							<p className="mb-28"> </p>
						</div>
					)}
					{accessMenuIsOpen === false && (
						<>
							<TextField
								variant="outlined"
								label="Cell Number"
								name="cellnumber"
								value={data.cellnumber}
								onChange={handleDataChange}
							/>
							<div style={{ width: "300px" }}>
								<p className="text-sm font-bold">Status</p>
								<Select
									className="basic-single"
									classNamePrefix="select"
									// defaultValue={selectedOption}
									isDisabled={false}
									// onChange={handleSelectionChange}
									// isLoading={isLoading}
									// isClearable={isClearable}
									// isRtl={isRtl}
									// isSearchable={isSearchable}
									onMenuOpen={handleStatusMenuOpen}
									onMenuClose={handleStatusMenuClose}
									name="status"
									options={statusOptions}
								/>
							</div>
						</>
					)}{" "}
					{accessMenuIsOpen === true && (
						<div>
							<p className="mb-28"> </p>
						</div>
					)}
					{statusMenuIsOpen === false && (
						<>
							<TextField
								// visible={menuIsOpen}
								variant="outlined"
								label="Comment"
								name="comment"
								value={data.comment}
								onChange={handleDataChange}
							/>
						</>
					)}
					{statusMenuIsOpen === true && (
						<div>
							<p className="mb-12"> </p>
						</div>
					)}
				</Stack>
			</DialogContent>
			<DialogActions>
				<Button variant="contained" color="success" onClick={onSaveData}>
					OK
				</Button>
				<Button variant="contained" color="error" onClick={onClose}>
					Close
				</Button>
			</DialogActions>
		</Dialog>
	);
};

const ValidationModal = ({ recordID, open, data, onUpdateData }) => {
	if (!open || !recordID) return null;

	const [showRecord, setShowRecord] = useState(false);
	// const [data, setData] = useState({
	// 	firstname: "",
	// 	lastname: "",
	// 	nickname: "",
	// 	company: "",
	// 	accesslevel: "",
	// 	email: "",
	// 	cellnumber: "",
	// 	status: "",
	// 	comment: "",
	// });

	const handleChange = ({ currentTarget: input }) => {
		// setData({ ...data, [input.name]: input.value });

		const updatedData = { ...data, [input.name]: input.value };
		onUpdateData(updatedData);
		WindowSharp.alert(`Data: ${JSON.stringify(updatedData)}`);
	};
	// Utilize useEffect to get Request Details
	// useEffect(() => {
	//   const fetchRequest = async () => {
	//     const apiUrl = process.env.REACT_APP_MONGO_URI;

	// 					// const fetchString = `${apiUrl}/api/request/${recordID}`;
	// 					const fetchString = `/api/request/${recordID}`;
	// 					// Set Wait Cursor
	// 					document.getElementById("root").style.cursor = "wait";
	// 					const response = await fetch(fetchString);
	// 					const json = await response.json();
	// 					// Set the Customer Name and remove double quotes at beginning and end
	// 					setCustomerName(
	// 						JSON.stringify(json.customername).replace(/^"(.*)"$/, "$1"),
	// 					);
	// 					setRigCompany(
	// 						JSON.stringify(json.rigcompany).replace(/^"(.*)"$/, "$1"),
	// 					);
	// 					setRequestName(
	// 						JSON.stringify(json.requestname).replace(/^"(.*)"$/, "$1"),
	// 					);
	// 					setRequestCategory(
	// 						JSON.stringify(json.requestcategory).replace(/^"(.*)"$/, "$1"),
	// 					);
	// 					const formattedDate = format(
	// 						new Date(json.datetimerequested),
	// 						"MMMM do yyyy, h:mm",
	// 					);
	// 					setDateTimeRequested(formattedDate);
	// 					// setDateTimeRequested(JSON.stringify(json.datetimerequested));
	// 					// Set Default Cursor
	// 					document.getElementById("root").style.cursor = "default";
	//   };
	//   fetchRequest();
	// }, []);

	const showID = () => {
		setShowRecord(!showRecord);
	};

	const inputFormat =
		"bg-gray-200 w-[100%] pt-1 pb-1 flex items-center mb-1 rounded-8xs shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] box-border border-[1px] border-solid border-black border-r-2 border-b-2 px-1";

	const buttonFormat =
		"bg-green-200 text-black p-0 rounded-lg w-24 items-center justify-center border-2 border-solid border-black border-r-4 border-b-4 text-base";

	const handleSubmit = async (e) => {
		e.preventDefault();
		window.alert(`Form Data: ${data.current}`);
		// if (data.firstName.length < 2 || data.firstName.length > 20) {
		// 	setError("First Name must be between 2 and 20 characters");
		// 	return;
		// }
		// if (data.lastName.length < 2 || data.lastName.length > 20) {
		// 	setError("Last Name must be between 2 and 20 characters");
		// 	return;
		// }
		// if (data.company.length < 2 || data.company.length > 20) {
		// 	setError("Company must be between 2 and 20 characters");
		// 	return;
		// }
		// if (data.phone.length < 10 || data.phone.length > 10) {
		// 	setError("Phone number must be 10 characters");
		// 	return;
		// }
		// if (data.email.length < 6 || data.email.length > 50) {
		// 	setError("Email must be between 6 and 50 characters");
		// 	return;
		// }
		// if (data.password.length < 6 || data.password.length > 20) {
		// 	setError("Password must be between 6 and 20 characters");
		// 	return;
		// }
		// const response = await fetch(
		// 	`${process.env.REACT_APP_MONGO_URI}/api/user/`,
		// 	{
		// 		method: "POST",
		// 		body: JSON.stringify(data),
		// 		headers: {
		// 			"Content-Type": "application/json",
		// 		},
		// 	},
		// );
		// const json = await response.json();
		// if (response.ok) {
		// 	toast.success("Check Email to Validate...User Still Must Be Validated");
		// 	navigate("/login");
		// }
	};

	return (
		<div
			// id="requestFrame"
			className="bg-white w-[100%] h-full overflow-hidden text-center text-lg text-black "
		>
			<div className="text-center text-xl font-bold pb-1">
				<span className="text-green-500">WORK</span>SIDE
			</div>
			<form className="flex flex-col items-center" onSubmit={handleSubmit}>
				{/* First Name */}
				<div className="flex-col w-[95%] ml-2 mr-2">
					<p className="text-left text-xs font-semibold">First Name</p>
					<div className={inputFormat}>
						<input
							type="text"
							name="firstName"
							placeholder="First Name"
							value={data.firstname}
							onChange={handleChange}
							className="bg-gray-200 outline-none text-sm flex-1"
						/>
					</div>
				</div>
				{/* End of First Name */}
				{/* Last Name */}
				<div className="flex-col w-[95%] ml-2 mr-2">
					<p className="text-left text-xs font-semibold">Last Name</p>
					<div className={inputFormat}>
						<input
							type="text"
							name="lastName"
							placeholder="Last Name"
							value={data.lastname}
							onChange={handleChange}
							className="bg-gray-200 outline-none text-sm flex-1"
						/>
					</div>
				</div>
				{/* End of Last Name */}
				{/* Nickname */}
				<div className="flex-col w-[95%] ml-2 mr-2">
					<p className="text-left text-xs font-semibold">Nickname</p>
					<div className={inputFormat}>
						<input
							type="text"
							name="nickName"
							placeholder="Nickname"
							value={data.nickname}
							onChange={handleChange}
							className="bg-gray-200 outline-none text-sm flex-1"
						/>
					</div>
				</div>
				{/* End of Last Name */}
				{/* Company */}
				<div className="flex-col w-[95%] ml-2 mr-2">
					<p className="text-left text-xs font-semibold">Company</p>
					<div className={inputFormat}>
						<input
							type="text"
							name="company"
							placeholder="Company"
							value={data.company}
							onChange={handleChange}
							className="bg-gray-200 outline-none text-sm flex-1"
						/>
					</div>
				</div>
				{/* End of Company */}
				{/* Access Level */}
				<div className="flex-col w-[95%] ml-2 mr-2">
					<p className="text-left text-xs font-semibold">Access Level</p>
					<div className={inputFormat}>
						<input
							type="text"
							name="accessLevel"
							placeholder="Access Level"
							value={data.accesslevel}
							onChange={handleChange}
							className="bg-gray-200 outline-none text-sm flex-1"
						/>
					</div>
				</div>
				{/* End of Access Level */}
				{/* Email */}
				<div className="flex-col w-[95%] ml-2 mr-2">
					<p className="text-left text-xs font-semibold">Email</p>
					<div className={inputFormat}>
						<input
							type="email"
							name="email"
							placeholder="Email"
							value={data.email}
							onChange={handleChange}
							className="bg-gray-200 outline-none text-sm flex-1"
						/>
					</div>
				</div>
				{/* End of Email */}
				{/* Cell Number */}
				<div className="flex-col w-[95%] ml-2 mr-2">
					<p className="text-left text-xs font-semibold">Cell Number</p>
					<div className={inputFormat}>
						<input
							type="text"
							name="cellNumber"
							placeholder="Cell Number"
							value={data.cellnumber}
							onChange={handleChange}
							className="bg-gray-200 outline-none text-sm flex-1"
						/>
					</div>
				</div>
				{/* End of Cell Number */}
				{/* Status */}
				<div className="flex-col w-[95%] ml-2 mr-2">
					<p className="text-left text-xs font-semibold">Status</p>
					<div className={inputFormat}>
						<input
							type="text"
							name="status"
							placeholder="Status"
							value={data.status}
							onChange={handleChange}
							className="bg-gray-200 outline-none text-sm flex-1"
						/>
					</div>
				</div>
				{/* End of Status */}
				{/* Comment */}
				<div className="flex-col w-[95%] ml-2 mr-2">
					<p className="text-left text-xs font-semibold">Comment</p>
					<div className={inputFormat}>
						<input
							type="text"
							name="comment"
							placeholder="Comment"
							value={data.comment}
							onChange={handleChange}
							className="bg-gray-200 outline-none text-sm flex-1"
						/>
					</div>
				</div>
				{/* End of Comment */}
				{/* <div className="flex-row gap-4 space-x-3 pt-3">
				<button
					type="button"
					disabled={false}
					// onClick={handleSubmit}
					className={buttonFormat}
				>
					Save
				</button>
				<button
					type="button"
					disabled={false}
					onClick={showID}
					className={buttonFormat}
				>
					Cancel
				</button>
			</div>
			{showRecord && (
				<div>
					<p>Record Id: {recordID}</p>
				</div>
			)} */}
			</form>
		</div>
	);
};

export default ValidateUsersTab;
